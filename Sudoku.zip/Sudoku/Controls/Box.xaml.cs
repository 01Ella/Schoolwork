﻿
using SudokuUWP.Models;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

namespace SudokuUWP.Controls
{
    public sealed partial class Box : UserControl
    {
        public BoxModel Value
        {
            get { return (BoxModel)GetValue(ValueProperty); }
            set
            {
                SetValue(ValueProperty, value);
            }
        }

        public static readonly DependencyProperty ValueProperty =
            DependencyProperty.Register("Value", typeof(BoxModel), typeof(Box), new PropertyMetadata(null));

        public Box()
        {
            this.InitializeComponent();
        }
    }
}
