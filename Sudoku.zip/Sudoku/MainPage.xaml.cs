﻿using SudokuUWP.Models;
using Windows.System;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Input;


namespace SudokuUWP
{
    public sealed partial class MainPage : Page
    {
        public MainPageViewModel ViewModel = new MainPageViewModel();

        public MainPage()
        {
            this.InitializeComponent();

            foreach (var level in DispGameLevel.Values)
            {
                levelMenu.Items.Add(new MenuFlyoutItem()
                {
                    Text = level.Text,
                    Command = ViewModel.LevelChangedCommand,
                    CommandParameter = level
                });
            }
        }

        private void ItemsWrapGrid_Loaded(object sender, RoutedEventArgs e)
        {
        }

        private void Box_Tapped(object sender, TappedRoutedEventArgs e)
        {
            FlyoutBase.ShowAttachedFlyout((FrameworkElement)sender);
        }

        private void Page_SizeChanged(object sender, SizeChangedEventArgs e)
        {
        }

        private void NumbersBoard_Selected(int? selectedValue)
        {
            numbersBoard.Hide();

            var selectedBox = gameBoard.SelectedItem as BoxModel;
            ViewModel.ValidateWhenChangeAt(selectedBox);
        }

        private void Page_KeyDown(object sender, KeyRoutedEventArgs e)
        {
            if (!ViewModel.IsPlaying)
            {
                return;
            }

            var selectedValue = gameBoard.SelectedItem as BoxModel;
            if (selectedValue == null)
            {
                return;
            }

            if (selectedValue.IsFixed)
            {
                return;
            }

            if (e.Key == VirtualKey.Back || e.Key == VirtualKey.Delete)
            {
                selectedValue.DisplayValue = null;
            }

            int digit = e.Key - VirtualKey.Number0;

            if (digit < 0 || digit > 9 || digit > ViewModel.Size)
            {
                return;
            }

            var newValue = digit + (selectedValue?.DisplayValue ?? 0) * 10;
            if (newValue > ViewModel.Size)
            {
                newValue = digit;
            }

            if (newValue != 0)
            {
                selectedValue.DisplayValue = newValue;
                ViewModel.ValidateWhenChangeAt(selectedValue);
            }
        }
    }
}
