﻿namespace SudokuUWP.Models
{
    internal class GameBox
    {
    }
}